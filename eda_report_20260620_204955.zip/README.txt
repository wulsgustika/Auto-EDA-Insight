Auto EDA Insight — Full Dashboard Export
Generated: 20 Jun 2026 20:49
File    : dataset
Rows    : 63
Columns : 5

Files in this archive:
  01_dataset_full.csv        — Complete dataset
  02_numerical_stats.csv     — Descriptive stats (numerical)
  03_categorical_stats.csv   — Descriptive stats (categorical)
  04_auto_insights.csv       — Auto-generated insights
  05_timeseries_summary.csv  — Time series summary (if available)
